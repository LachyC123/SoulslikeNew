PIXEL DUNGEON GAME PLAN

Extract the entire ZIP before opening.

PIXEL_DUNGEON_GAME_PLAN.md contains the complete design plan. Open it in a Markdown viewer/editor, or upload it to your coding assistant alongside the three PNG images in references/.

The references folder contains the approved early-region, later-combat and equipment-interface concepts. Keep it beside the plan so the relative image links continue to work.

These are design documents and visual references, not a playable game.
